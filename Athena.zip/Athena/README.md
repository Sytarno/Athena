# Athena
Discord bot made by me, Sytarno#8065

This bot will not run on its own. .env.txt is a missing file that contains the token and other private info I will not divulge.

(EXTRAS)
bot.py is the main core that is required to run. 
however, in order for youtube pull/push requests, lavalink.jar in the folder lavalink needs to run concurrently.

musicNew.py is the currently used cog for youtube.
musicPl.py is deprecated and only serves as a reminder of what I made. 
This should never be added as a cog because it uses ffmpeg which needs separate installation, and opens up unnecessary boxes during runtime.
